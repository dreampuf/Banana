<?php get_header(); ?>
	<div id="main">
		<div id="maincontent"><div class="forFlow">
		<div class="navigation-top"><span>您的位置：</span><a href="<?php bloginfo('url'); ?>">首页</a> > <?php the_category(', ') ?> > <a href="<?php the_permalink(); ?>"title="<?php the_title(); ?>"><?php the_title(); ?></a></div>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="post" id="post-<?php the_ID(); ?>">
				<h2 class="post-tltle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				<div class="postmetadata-top">
					<span class="post-comments"><a href="#respond"><?php comments_number('No comments', '1 comment', '% comments'); ?></a></span>
					<span class="post-date"><?php the_time('Y/m/d H:i') ?></span>
					<span class="post-views"><?php if(function_exists('the_views')) {the_views();} ?></span>
				</div>
				<div class="entry">
					<?php the_content(); ?>
				</div>
				<div class="postmetadata">
					<span class="post-cat"><?php the_category(',') ?></span>
					<span class="post-author"><?php the_author_posts_link(); ?></span>
					<span class="post-tag"><?php the_tags('', ',', ''); ?></span>
				</div>
			</div>
			<div class="navigation">
				<?php previous_post('<span class="previous">%</span>','','yes') ?>
				<?php next_post('<span class="next">%</span>','','yes') ?>
			</div>

			<div class="related">
				<h4>相关文章</h4>
				<ul><?php wp_related_posts(); ?></ul>
			</div>
		<?php comments_template(); ?>
		<?php endwhile; else: ?>
			<h2 class="center">Not Found</h2>
			<p class="center">不好意思，您所查看的内容不再这里，您可以通过侧栏搜索工具查一下。</p>
		<?php endif; ?>
		</div></div>
	<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>