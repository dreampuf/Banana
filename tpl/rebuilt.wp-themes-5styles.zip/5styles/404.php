<?php get_header(); ?>
	<div id="main">
		<div id="maincontent"><div class="forFlow">
			<div class="navigation-top"><span>您的位置：</span>搜索结果</div>
			<div class="title"><h2 class="post-tltle">404错误,没有找到你要的文章</h2></div>
			<p>您可以在右侧搜索栏再搜一下</p>
		</div></div>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>