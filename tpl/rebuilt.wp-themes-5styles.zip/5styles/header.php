<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<script language="JavaScript" type="text/javascript">

var arrCSS=[
["<img src='<?php bloginfo('stylesheet_directory'); ?>/images/layout1.png' width='10' height='10' class='themes' alt='layout1'>","<?php bloginfo('stylesheet_directory'); ?>/layout1.css"],
["<img src='<?php bloginfo('stylesheet_directory'); ?>/images/layout2.png' width='10' height='10' class='themes' alt='layout2'>","<?php bloginfo('stylesheet_directory'); ?>/layout2.css"],
["<img src='<?php bloginfo('stylesheet_directory'); ?>/images/layout3.png' width='10' height='10' class='themes' alt='layout3'>","<?php bloginfo('stylesheet_directory'); ?>/layout3.css"],
["<img src='<?php bloginfo('stylesheet_directory'); ?>/images/layout4.png' width='10' height='10' class='themes' alt='layout4'>","<?php bloginfo('stylesheet_directory'); ?>/layout4.css"],
["<img src='<?php bloginfo('stylesheet_directory'); ?>/images/layout5.png' width='10' height='10' class='themes' alt='layout5'>","<?php bloginfo('stylesheet_directory'); ?>/layout5.css"],
""
];


// *** function to replace href="#" ***
function v(){
	return;
}

// *** Cookies ***
function writeCookie(name, value) { 
    //alert(name+"@"+value);
	exp = new Date(); 
	exp.setTime(exp.getTime() + (86400 * 1000 * 30));
	document.cookie = name + "=" + escape(value) + "; expires=" + exp.toGMTString() + "; path=/"; 
	document.cookie.replace("stylesheet=css0","stylesheet="+value);
	//alert(document.cookie);
} 
function readCookie(name) { 
	var search; 
	search = name + "="; 
	offset = document.cookie.indexOf(search); 
	if (offset != -1) { 
		offset += search.length; 
		end = document.cookie.indexOf(";", offset); 
		if (end == -1){
			end = document.cookie.length;
		}
		//alert(document.cookie.substring(offset, end));
		return unescape(document.cookie.substring(offset, end)); 
	}else{
		return "";
	}
}


// StyleSheet

function writeCSS(){
  for(var i=0;i<arrCSS.length;i++){
    document.write('<link title="css'+i+'" href="'+arrCSS[i][1]+'" rel="stylesheet" disabled="true" type="text/css" />');
  }
    setStyleSheet(readCookie("stylesheet"));
}

function writeCSSLinks(){
  for(var i=0;i<arrCSS.length-1;i++){
    if(i>0) document.write('  ');
    document.write('<a href="javascript:v()" onclick="setStyleSheet(\'css'+i+'\')">'+arrCSS[i][0]+'</a>');
  }
}

function setStyleSheet(strCSS){
  var objs=document.getElementsByTagName("link");
  var intFound=0;
  for(var i=0;i<objs.length;i++){
    if(objs[i].type.indexOf("css")>-1&&objs[i].title){
      objs[i].disabled = true;
      if(objs[i].title==strCSS) intFound=i;
    }
  }
  objs[intFound].disabled = false;
  writeCookie("stylesheet",objs[intFound].title);
}

writeCSS();
setStyleSheet(readCookie("stylesheet"));

//-->
</script>

<head profile="http://gmpg.org/xfn/11">
	<title><?php if (is_single() || is_page() || is_archive()) { ?><?php wp_title('',true); ?> | <?php } bloginfo('name'); ?> </title>
	<?php if (is_single() || is_page() || is_home() || is_category() ) : ?><meta name="robots" content="index,follow" /><?php else : ?>	<meta name="robots" content="noindex,follow" /><?php endif; ?>

	<meta http-equiv="Content-Type" content="<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
	<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen, projection" id="cssfile"/>

	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php wp_head(); ?>
</head>
<body>
	<div id="wrap">
		<div id="header">
			<div id="header-left">
				<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
				<div class="description"><?php bloginfo('description'); ?></div>
			</div>
			<div id="header-right">
				<div class="layout">
					<script type="text/javascript">writeCSSLinks();</script>
				</div>

				<div id="menu">
					<li class="<?php if ( is_home() ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php echo get_settings('home'); ?>" title="<?php bloginfo('name'); ?>">首页</a></li>
					<?php wp_list_pages('title_li=&depth=1'); ?>
				</div>
			</div>
		</div>