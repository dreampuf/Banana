<div id="footer">

			<div id="footer-wp"></div>

			<div id="footer-link"><p>动力驱动 <a rel="nofollow" href="http://wordpress.org" target="_blank">WordPress</a> </p>  

			<p><a href="http://marslau.com/archives/454.html" target="_blank" title="WordPress主题5Styles">5Styles</a> 主题由 <a href="http://marslau.com" target="_blank" title="Mars Lau's blog">Mars Lau</a> 提供</p>

			</div>

		</div>

	</div>
    <?php wp_footer(); ?> 
</body>
</html>
